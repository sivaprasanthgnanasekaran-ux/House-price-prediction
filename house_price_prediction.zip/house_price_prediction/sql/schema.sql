CREATE TABLE IF NOT EXISTS house_listings (
    id SERIAL PRIMARY KEY,
    lot_area NUMERIC,
    overall_qual INT,
    overall_cond INT,
    year_built INT,
    year_remod INT,
    total_bsmt_sf NUMERIC,
    gr_liv_area NUMERIC,
    full_bath INT,
    half_bath INT,
    bedroom_abvgr INT,
    kitchen_abvgr INT,
    garage_cars INT,
    garage_area NUMERIC,
    neighborhood VARCHAR(50),
    sale_price NUMERIC,
    sale_date DATE
);

-- SELECT * FROM house_listings
-- WHERE sale_price IS NOT NULL;
