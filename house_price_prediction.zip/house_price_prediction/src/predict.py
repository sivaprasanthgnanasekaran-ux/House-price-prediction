import joblib
import numpy as np
import pandas as pd

from preprocess import engineer_features

MODEL_PATH = "models/house_price_model.pkl"
_pipeline = None


def get_pipeline():
    global _pipeline
    if _pipeline is None:
        _pipeline = joblib.load(MODEL_PATH)
    return _pipeline


def predict_price(input_dict: dict) -> float:
    pipeline = get_pipeline()
    df = pd.DataFrame([input_dict])
    df = engineer_features(df)
    pred_log = pipeline.predict(df)[0]
    return float(np.expm1(pred_log))
