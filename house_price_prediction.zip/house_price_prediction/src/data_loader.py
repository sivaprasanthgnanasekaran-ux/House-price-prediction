import os
import pandas as pd
from sqlalchemy import create_engine

DB_URL = os.getenv("HOUSING_DB_URL")
QUERY = "SELECT * FROM house_listings WHERE sale_price IS NOT NULL;"


def load_from_sql(query: str = QUERY) -> pd.DataFrame:
    if not DB_URL:
        raise RuntimeError("HOUSING_DB_URL environment variable is not set.")
    engine = create_engine(DB_URL)
    with engine.connect() as conn:
        return pd.read_sql(query, conn)


def load_from_csv(path="data/house_prices.csv"):
    return pd.read_csv(path)


def load_data(prefer_sql=True):
    if prefer_sql and DB_URL:
        try:
            return load_from_sql()
        except Exception as e:
            print(f"[data_loader] SQL load failed ({e}), falling back to CSV.")
            return load_from_csv()
    return load_from_csv()
