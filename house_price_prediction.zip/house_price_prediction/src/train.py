import os
import joblib
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from xgboost import XGBRegressor

from data_loader import load_data
from preprocess import build_preprocessor, prepare_xy

MODEL_PATH = "models/house_price_model.pkl"


def main():
    df = load_data()
    X, y = prepare_xy(df)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = XGBRegressor(
        n_estimators=600, max_depth=4, learning_rate=0.03,
        subsample=0.8, colsample_bytree=0.8,
        reg_alpha=0.1, reg_lambda=1.0,
        random_state=42, n_jobs=-1,
    )
    pipeline = Pipeline(steps=[
        ("preprocessor", build_preprocessor()),
        ("model", model),
    ])

    cv_scores = cross_val_score(
        pipeline, X_train, y_train, cv=5, scoring="neg_root_mean_squared_error"
    )
    print(f"CV RMSE (log scale): {-cv_scores.mean():.4f} +/- {cv_scores.std():.4f}")

    pipeline.fit(X_train, y_train)
    preds = np.expm1(pipeline.predict(X_test))
    actual = np.expm1(y_test)

    rmse = float(np.sqrt(mean_squared_error(actual, preds)))
    mae = mean_absolute_error(actual, preds)
    r2 = r2_score(actual, preds)
    print(f"RMSE: {rmse:,.2f}")
    print(f"MAE : {mae:,.2f}")
    print(f"R2  : {r2:.4f}")

    os.makedirs("models", exist_ok=True)
    joblib.dump(pipeline, MODEL_PATH)
    print(f"Saved pipeline to {MODEL_PATH}")


if __name__ == "__main__":
    main()
