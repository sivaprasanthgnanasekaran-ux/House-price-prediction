import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUMERIC_FEATURES = [
    "lot_area", "overall_qual", "overall_cond", "year_built", "year_remod",
    "total_bsmt_sf", "gr_liv_area", "full_bath", "half_bath",
    "bedroom_abvgr", "kitchen_abvgr", "garage_cars", "garage_area",
]
CATEGORICAL_FEATURES = ["neighborhood"]
EXTRA_NUMERIC = ["house_age", "years_since_remod", "total_bath", "total_sf"]
TARGET = "sale_price"

# Fixed reference year (latest year in the Ames-style dataset).
# NOTE: the report used df["year_built"].max(); on a single-row input that is
# always 0 at prediction time, so a constant reference is used instead.
REFERENCE_YEAR = 2010


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["house_age"] = REFERENCE_YEAR - df["year_built"]
    df["years_since_remod"] = REFERENCE_YEAR - df["year_remod"]
    df["total_bath"] = df["full_bath"] + 0.5 * df["half_bath"]
    df["total_sf"] = df["total_bsmt_sf"].fillna(0) + df["gr_liv_area"].fillna(0)
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.dropna(subset=[TARGET])
    q1, q3 = df[TARGET].quantile([0.01, 0.99])
    return df[(df[TARGET] >= q1) & (df[TARGET] <= q3)]


def build_preprocessor() -> ColumnTransformer:
    numeric_pipe = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    return ColumnTransformer(transformers=[
        ("num", numeric_pipe, NUMERIC_FEATURES + EXTRA_NUMERIC),
        ("cat", categorical_pipe, CATEGORICAL_FEATURES),
    ])


def prepare_xy(df: pd.DataFrame):
    df = clean_data(df)
    df = engineer_features(df)
    X = df[NUMERIC_FEATURES + EXTRA_NUMERIC + CATEGORICAL_FEATURES]
    y = np.log1p(df[TARGET])
    return X, y
