import sys
sys.path.insert(0, "src")

import streamlit as st
from predict import predict_price

st.set_page_config(page_title="House Price Predictor", page_icon="🏠", layout="centered")
st.title("🏠 House Price Predictor")
st.write("Enter the property details to estimate the sale price.")

with st.form("prediction_form"):
    col1, col2 = st.columns(2)
    with col1:
        lot_area = st.number_input("Lot Area (sq ft)", 500, 50000, 8000)
        overall_qual = st.slider("Overall Quality (1-10)", 1, 10, 6)
        overall_cond = st.slider("Overall Condition (1-10)", 1, 10, 5)
        year_built = st.number_input("Year Built", 1900, 2026, 2000)
        year_remod = st.number_input("Year Remodeled", 1900, 2026, 2005)
        total_bsmt_sf = st.number_input("Total Basement Area (sq ft)", 0, 6000, 900)
        gr_liv_area = st.number_input("Above-Ground Living Area (sq ft)", 300, 6000, 1500)
    with col2:
        full_bath = st.number_input("Full Bathrooms", 0, 5, 2)
        half_bath = st.number_input("Half Bathrooms", 0, 3, 1)
        bedroom_abvgr = st.number_input("Bedrooms", 0, 10, 3)
        kitchen_abvgr = st.number_input("Kitchens", 0, 3, 1)
        garage_cars = st.number_input("Garage Capacity (cars)", 0, 5, 2)
        garage_area = st.number_input("Garage Area (sq ft)", 0, 1500, 480)
        neighborhood = st.text_input("Neighborhood", value="NAmes")

    submitted = st.form_submit_button("Predict Price")

if submitted:
    input_dict = {
        "lot_area": lot_area, "overall_qual": overall_qual,
        "overall_cond": overall_cond, "year_built": year_built,
        "year_remod": year_remod, "total_bsmt_sf": total_bsmt_sf,
        "gr_liv_area": gr_liv_area, "full_bath": full_bath,
        "half_bath": half_bath, "bedroom_abvgr": bedroom_abvgr,
        "kitchen_abvgr": kitchen_abvgr, "garage_cars": garage_cars,
        "garage_area": garage_area, "neighborhood": neighborhood,
    }
    try:
        price = predict_price(input_dict)
        st.success(f"Estimated Sale Price: ${price:,.0f}")
    except FileNotFoundError:
        st.error("Model file not found. Please run `python src/train.py` first.")
    except Exception as e:
        st.error(f"Prediction failed: {e}")
