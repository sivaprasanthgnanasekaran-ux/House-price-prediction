# AWS Deployment Notes

Architecture: RDS (PostgreSQL) -> ECR (image) -> ECS Fargate / App Runner -> ALB (port 8501).
Secrets Manager holds `HOUSING_DB_URL`; S3 optionally stores the trained model.

```bash
aws ecr create-repository --repository-name house-price-app
docker build -t house-price-app .
docker tag house-price-app:latest <account_id>.dkr.ecr.<region>.amazonaws.com/house-price-app:latest
docker push <account_id>.dkr.ecr.<region>.amazonaws.com/house-price-app:latest

python src/train.py
aws s3 cp models/house_price_model.pkl s3://<your-bucket>/models/house_price_model.pkl
```
