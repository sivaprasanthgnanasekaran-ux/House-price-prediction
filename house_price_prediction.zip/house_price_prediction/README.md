# House Price Prediction System

## Run locally
```bash
pip install -r requirements.txt
python src/train.py          # trains and saves models/house_price_model.pkl
streamlit run app.py
```
Set `HOUSING_DB_URL` (e.g. postgresql://user:pass@host/db) to load from SQL (table in sql/schema.sql);
otherwise data/house_prices.csv is used.

## Note on data
data/house_prices.csv is SYNTHETIC sample data (1,460 rows) so the project runs out of the box.
Replace it with your real dataset (same column names) for meaningful results.
